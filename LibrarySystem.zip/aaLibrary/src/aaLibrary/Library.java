package aaLibrary;
import java.util.ArrayList;

import aaLibrary.Book;
import aaLibrary.Library;

public class Library {
    private String name;
    private ArrayList<Book> books;

    public Library(String name) {
        this.name = name;
        this.books = new ArrayList<>();
    }

    public void addBook(String title, String author, int yearPublished) {
        Book book = new Book(title, author, yearPublished);
        this.books.add(book);
        System.out.println(title + " added to library.");
    }

    public void removeBook(String title) {
        for (Book book : this.books) {
            if (book.getTitle().equals(title)) {
                this.books.remove(book);
                System.out.println(title + " removed from library.");
                return;
            }
        }
        System.out.println(title + " not found in library.");
    }

    public void printBooks() {
        if (this.books.size() == 0) {
            System.out.println("No books in library.");
        } else {
            System.out.println(this.name + " Books:");
            for (Book book : this.books) {
                System.out.println(book.getTitle() + " by " + book.getAuthor() + " (" + book.getYearPublished() + ")");
            }
        }
    }
}

class Book {
    private String title;
    private String author;
    private int yearPublished;

    public Book(String title, String author, int yearPublished) {
        this.title = title;
        this.author = author;
        this.yearPublished = yearPublished;
    }

    public String getTitle() {
        return this.title;
    }

    public String getAuthor() {
        return this.author;
    }

    public int getYearPublished() {
        return this.yearPublished;
    }
}

class Main {
    public static void main(String[] args) {
        Library library = new Library("My Library");

        library.addBook("Jujutsu Kaisen Vol.1", "Gege Akutami", 2018);
        library.addBook("Jujutsu Kaisen, Vol.2", "Gege Akutami", 2018);
        library.printBooks();

        library.removeBook("Jujutsu Kaisen Vol.1");
        library.printBooks();

        library.addBook("Jujutsu Kaisen Vol.3", "Gege Akutami", 2018);
        library.printBooks();
    }
}

